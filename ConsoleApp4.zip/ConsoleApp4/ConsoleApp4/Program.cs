﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the name of the car:");
            string carName = Console.ReadLine();
            Console.WriteLine($"Enter the fuel consumption rate of the {carName} in liters per 100 kilometers:");
            double fuelConsumptionRate = double.Parse(Console.ReadLine());
            Console.WriteLine($"Enter the tank capacity of the {carName} in liters:");
            double tankCapacity = double.Parse(Console.ReadLine());

            Console.WriteLine("Enter the distance to be covered in kilometers:");
            double distance = double.Parse(Console.ReadLine());

            double fuelRequired = (fuelConsumptionRate / 100) * distance;
            Console.WriteLine($"The {carName} will require {fuelRequired:F2} liters of fuel for the trip.");

            int refillsRequired = (int)Math.Ceiling(fuelRequired / tankCapacity);
            Console.WriteLine($"You will need to refill the tank of the {carName} {refillsRequired} times.");

            Console.ReadLine();
        }
    }
}
