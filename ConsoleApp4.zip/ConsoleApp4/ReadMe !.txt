Program Name: Fuel Calculator
The program helps the user to understand how many liters of gasoline the car will burn in a certain section. The user must enter:
1. Car name
2. How many liters does the car burn per 100 kilometers
3. How many liters of petrol tank does the car have
4. How many kilometers the user plans to cover

After entering all this, the program will automatically generate how many liters the user will need to cover this distance and tell him how many times he will have to fill the tank.

ქართულად:

პროგრამის სახელი: საწვავის კალკულატორი
პროგრამა მომხმარებელს ეხმარება რომ გაიგოს თუ რამდენ ლიტრ ბენზინს დაწვავს მანქანა გარკვეულ მონაკვეთში. მომხმარებელმა უნდა შეიყვანოს: 
1. მანქანის დასახელება
2. რამდენ ლიტრს წვავს მანქანა 100 კილომეტრზე
3. რამდენ ლიტრიანი ბენზინის ავზი აქვს მანქანას
4. რამდენი კილომეტრის დაფარვას გეგმავს მომხმარებელი

ამ ყველაფრის შეყვანის შემდეგ პროგრამა ავტომატურად დააგენერირებს თუ რამდენი ლიტრი დასჭირდება მომხმარებელს ამ მანძილის დასაფარად და ეტყვის თუ რამდენჯერ მოუწევს მას ავზის ავსება.